Respected Sir,
The main code has the name as that of the zip file's name.
The required functions for the main code are convolve.m and ncc.m
Please change the working directory of matlab to this directory/(the folder containg all the images and the functions). 